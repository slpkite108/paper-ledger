'use client';
import { useEffect, useRef, useState } from 'react';
import { BookOpen, Search, Download, ArrowUpRight, Pencil, Check, Loader2, Info, UserRound, Plus, CircleHelp, Library, Settings2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Table, TableBody, TableHead, TableHeader, TableRow, TableCell } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Empty, EmptyHeader, EmptyTitle, EmptyDescription, EmptyMedia } from '@/components/ui/empty';
import { Skeleton } from '@/components/ui/skeleton';
import { fields, makeCsv, safeUrl, shortId, toPaper, validationError, type Author, type Paper, type Work, type FieldKey } from '@/lib/papers';

import { getData, ClientApiError, isStandalone } from '@/lib/client-api';
import { AuthorFavorites } from '@/components/author-favorites';
import { SearchSettings } from '@/components/search-settings';
import { GoogleSettings } from '@/components/google-settings';
import { accountRequest, type AccountInfo } from '@/lib/account-client';
import type { Favorite } from '@/lib/favorites';
import { kindLabels, visiblePublications, type PublicationKind } from '@/lib/publications';
import type { CrossrefData } from '@/lib/crossref-data';

function saveFile(content: string, filename: string) { const url = URL.createObjectURL(new Blob([content], { type: 'text/csv;charset=utf-8;' })); const a = document.createElement('a'); a.href = url; a.download = filename; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000); }
const count = (n: number) => n.toLocaleString('ko-KR');

export default function Home() {
  const [query, setQuery] = useState(''); const [searched, setSearched] = useState('');
  const [authors, setAuthors] = useState<Author[]>([]); const [authorTotal, setAuthorTotal] = useState(0); const [authorPage, setAuthorPage] = useState(1);
  const [searching, setSearching] = useState(false); const [searchError, setSearchError] = useState('');
  const [chosenAuthors, setChosenAuthors] = useState<Author[]>([]);
  const [professorNames, setProfessorNames] = useState<Record<string, string>>({});
  const [from, setFrom] = useState(''); const [to, setTo] = useState('');
  const [excludeArxiv, setExcludeArxiv] = useState(false); const [mergeLatest, setMergeLatest] = useState(true);
  const [publicationKind, setPublicationKind] = useState<PublicationKind | 'all'>('all');
  const [account, setAccount] = useState<AccountInfo | null>(null); const [accountError, setAccountError] = useState('');
  const [classifying, setClassifying] = useState(false); const [classificationStatus, setClassificationStatus] = useState(''); const classificationSeq = useRef(0);
  const [papers, setPapers] = useState<Paper[]>([]); const [selected, setSelected] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(false); const [paperError, setPaperError] = useState('');
  const [authorStats, setAuthorStats] = useState<Record<string, { total: number; loaded: number; cursor: string | null }>>({});
  const [loaded, setLoaded] = useState(false); const [workingAuthor, setWorkingAuthor] = useState('');
  const [applied, setApplied] = useState({ from: '', to: '' }); const [notice, setNotice] = useState('');
  const [editing, setEditing] = useState<Paper | null>(null); const [editError, setEditError] = useState(''); const [enriching, setEnriching] = useState(false);
  const [help, setHelp] = useState(false); const paperCache = useRef(new Map<string, Paper>()); const searchSeq = useRef(0); const worksSeq = useRef(0); const editSeq = useRef(0);
  const dirty = useRef(false);
  const apiKey = useRef('');
  const [keyActive, setKeyActive] = useState(false); const [serverKeyConfigured, setServerKeyConfigured] = useState(false);
  const [settings, setSettings] = useState(false);
  useEffect(() => { getData<{ serverKeyConfigured: boolean }>('/api/search-settings').then(d => setServerKeyConfigured(d.serverKeyConfigured)).catch(() => {}); }, []);
  useEffect(() => { if (!isStandalone()) accountRequest<AccountInfo>('/api/account').then(setAccount).catch(e => setAccountError(e.message)); }, []);
  function applyKey(key: string) {
    apiKey.current = key; setKeyActive(Boolean(key)); setSearchError(''); setPaperError('');
    setNotice(key ? '이 탭에 개인 키를 적용했습니다. 다시 조회하세요.' : isStandalone() ? '이 탭의 개인 키를 해제했습니다.' : '이 탭의 개인 키를 해제했습니다. 계정에 저장된 키가 있으면 자동으로 사용합니다.');
  }
  function restoreFavorite(favorite: Favorite) {
    ++classificationSeq.current; setClassifying(false); setClassificationStatus('');
    const p = favorite.payload;
    setChosenAuthors(p.authors); setProfessorNames(p.professorNames); setFrom(p.from); setTo(p.to);
    setExcludeArxiv(p.excludeArxiv); setMergeLatest(p.mergeLatest); setPublicationKind(p.publicationKind);
    setPapers([]); setSelected(new Set()); setAuthorStats({}); setLoaded(false); setPaperError('');
    setNotice(favorite.name + ' 목록을 불러왔습니다. 선택 저자 논문 불러오기를 눌러 조회하세요.');
  }
  async function classifyPapers(targets: Paper[]) {
    const candidates = targets.filter(p => p.doi && !p.arxiv && p.kindSource !== '직접 확인');
    const dois = [...new Set(candidates.map(p => p.doi.toLowerCase()))]; if (!dois.length) return;
    const seq = ++classificationSeq.current; setClassifying(true); let index = 0; let done = 0; let failed = 0; let stopped = false;
    const run = async () => {
      while (index < dois.length && seq === classificationSeq.current && !stopped) {
        const doi = dois[index++];
        try {
          const data = await getData<CrossrefData>('/api/crossref?' + new URLSearchParams({ doi }));
          if (seq !== classificationSeq.current) return;
          const update = (p: Paper) => p.doi.toLowerCase() === doi && p.kindSource !== '직접 확인' ? { ...p,
            ...(data.publicationKind !== 'unknown' || p.publicationKind === 'unknown' ? { publicationKind: data.publicationKind, kindSource: data.kindSource } : {}),
            values: { ...p.values, venue: p.values.venue || data.venue || '' } } : p;
          paperCache.current.forEach((p, id) => paperCache.current.set(id, update(p)));
          setPapers(prev => prev.map(update));
        } catch (e) { failed++; if (e instanceof ClientApiError && [429, 503].includes(e.status)) stopped = true; }
        if (seq !== classificationSeq.current) return;
        setClassificationStatus('Crossref 학술유형 확인 ' + (++done) + ' / ' + dois.length + ' DOI');
      }
    };
    await Promise.all([run(), run()]);
    if (seq === classificationSeq.current) { setClassifying(false); setClassificationStatus('Crossref 확인 완료: ' + done + ' / ' + dois.length + ' DOI' + (failed ? ' · ' + failed + '건 확인 실패' : '') + (stopped ? ' · 요청 제한으로 중단됨' : '')); }
  }
  useEffect(() => { const warn = (e: BeforeUnloadEvent) => { if (dirty.current) { e.preventDefault(); e.returnValue = ''; } }; window.addEventListener('beforeunload', warn); return () => window.removeEventListener('beforeunload', warn); }, []);
  const visiblePapers = visiblePublications(papers, { excludeArxiv, mergeLatest, publicationKind });
  const selectedPapers = visiblePapers.filter(p => selected.has(p.id)); const verifiedCount = visiblePapers.filter(p => p.verified).length;
  const total = Object.values(authorStats).reduce((sum, s) => sum + s.total, 0);
  const moreAvailable = chosenAuthors.some(a => !authorStats[a.id] || (authorStats[a.id].cursor && authorStats[a.id].loaded < authorStats[a.id].total));
  async function search(page = 1) {
    if (query.trim().length < 2) { setSearchError('이름이나 식별자를 2자 이상 입력하세요.'); return; }
    const seq = ++searchSeq.current; setSearching(true); setSearchError(''); const term = page === 1 ? query.trim() : searched;
    try { const data = await getData<{ authors: Author[]; total: number }>('/api/authors?' + new URLSearchParams({ q: term, page: String(page) }), apiKey.current); if (seq !== searchSeq.current) return;
      setAuthors(prev => page === 1 ? data.authors : [...prev, ...data.authors]); setAuthorTotal(data.total); setAuthorPage(page); setSearched(term);
    } catch(e) { if (seq === searchSeq.current) setSearchError((e as Error).message); }
    finally { if (seq === searchSeq.current) setSearching(false); }
  }
  function pickAuthor(a: Author) {
    if (loading) return;
    const removing = chosenAuthors.some(v => v.id === a.id);
    setChosenAuthors(prev => removing ? prev.filter(v => v.id !== a.id) : [...prev, a]);
    if (removing) {
      setPapers(prev => prev.filter(p => p.authorId !== a.id));
      setSelected(prev => new Set([...prev].filter(id => !id.startsWith(shortId(a.id) + ':'))));
      setAuthorStats(prev => { const next = { ...prev }; delete next[a.id]; return next; });
    }
    setLoaded(false); setPaperError(''); setNotice('');
  }
  function renameProfessor(a: Author, name: string) {
    setProfessorNames(prev => ({ ...prev, [a.id]: name }));
    const update = (p: Paper) => p.authorId === a.id ? { ...p, values: { ...p.values, professor: name.trim() || a.display_name } } : p;
    paperCache.current.forEach((p, key) => paperCache.current.set(key, update(p)));
    setPapers(prev => prev.map(update)); if (papers.length) dirty.current = true;
  }
  async function loadPapers(more = false) {
    if (!chosenAuthors.length || loading) return;
    const years = more ? applied : { from, to };
    if ([years.from, years.to].some(y => y && (!/^\d{4}$/.test(y) || +y < 1000 || +y > 2100)) || (years.from && years.to && +years.from > +years.to)) { setPaperError('조회 연도는 1000~2100 범위이며, 시작 연도가 종료 연도보다 늦을 수 없습니다.'); return; }
    ++classificationSeq.current; setClassifying(false); setClassificationStatus('');
    const typeCandidates: Paper[] = [];
    const seq = ++worksSeq.current; setLoading(true); setPaperError(''); setNotice('');
    const targets = more ? chosenAuthors.filter(a => !authorStats[a.id] || (authorStats[a.id].cursor && authorStats[a.id].loaded < authorStats[a.id].total)) : chosenAuthors;
    const errors: string[] = []; let successes = 0;
    for (const a of targets) {
      setWorkingAuthor(a.display_name);
      try {
        const cursor = more ? authorStats[a.id]?.cursor : null;
        const data = await getData<{ works: Work[]; total: number; cursor: string | null }>('/api/works?' + new URLSearchParams({ author: shortId(a.id), ...years, ...(cursor ? { cursor } : {}) }), apiKey.current);
        if (seq !== worksSeq.current) return;
        if (!more && successes === 0) { setPapers([]); setSelected(new Set()); setAuthorStats({}); }
        setApplied(years);
        const next = data.works.map(w => { const p = toPaper(w, a, professorNames[a.id] ?? a.display_name); const cached = paperCache.current.get(p.id); return cached ? { ...cached, values: { ...cached.values, professor: professorNames[a.id]?.trim() || a.display_name } } : p; });
        next.forEach(p => paperCache.current.set(p.id, p)); typeCandidates.push(...next.filter(p => p.publicationKind === 'unknown'));
        setPapers(prev => [...new Map([...prev, ...next].map(p => [p.id, p])).values()].sort((a, b) => b.values.published.localeCompare(a.values.published) || a.values.professor.localeCompare(b.values.professor)));
        setSelected(prev => new Set([...prev, ...next.map(p => p.id)]));
        setAuthorStats(prev => ({ ...prev, [a.id]: { total: data.total, loaded: (more ? prev[a.id]?.loaded ?? 0 : 0) + data.works.length, cursor: data.cursor } }));
        successes++;
      } catch (e) {
        errors.push(a.display_name + ': ' + (e as Error).message);
        if (e instanceof ClientApiError && [429, 401, 403].includes(e.status)) { errors.push('남은 저자의 요청을 중단했습니다. 기존 조회 결과와 편집 내용은 유지됩니다.'); break; }
      }
    }
    if (seq === worksSeq.current) { setLoading(false); setWorkingAuthor(''); setLoaded(successes > 0); setPaperError(errors.join(' / ')); if (typeCandidates.length) void classifyPapers(typeCandidates); }
  }
  function openEdit(p: Paper) { ++editSeq.current; setEditing({ ...p, values: { ...p.values } }); setEditError(''); setEnriching(false); }
  function closeEdit() { ++editSeq.current; setEditing(null); setEnriching(false); }
  function setValue(key: FieldKey, value: string) { setEditing(prev => prev ? { ...prev, values: { ...prev.values, [key]: value } } : null); }
  function commitEdit() { if (!editing) return; const error = validationError(editing.values); if (error) { setEditError(error); return; } paperCache.current.set(editing.id, editing); setPapers(prev => prev.map(p => p.id === editing.id ? editing : p)); dirty.current = true; closeEdit(); setNotice('수정한 내용을 반영했습니다. CSV를 저장하면 파일에 포함됩니다.'); }
  async function enrich() {
    if (!editing) return; const seq = editSeq.current; setEnriching(true); setEditError('');
    try { const data = await getData<CrossrefData>('/api/crossref?' + new URLSearchParams({ doi: editing.doi })); if (seq !== editSeq.current) return;
      setEditing(prev => { if (!prev) return prev; const values = { ...prev.values }; for (const key of ['pages', 'volume', 'published', 'venue', 'issn', 'link'] as const) if (!values[key] && data[key]) values[key] = data[key]; return { ...prev, values, ...(prev.kindSource !== '직접 확인' && data.publicationKind !== 'unknown' ? { publicationKind: data.publicationKind, kindSource: data.kindSource } : {}) }; }); setEditError('Crossref에서 빈 서지정보를 보완했습니다. 기존 입력값은 유지됩니다.');
    } catch(e) { if (seq === editSeq.current) setEditError((e as Error).message); } finally { if (seq === editSeq.current) setEnriching(false); }
  }
  function toggle(id: string, checked: boolean) { setSelected(prev => { const next = new Set(prev); checked ? next.add(id) : next.delete(id); return next; }); }
  function download() { saveFile(makeCsv(selectedPapers), '논문대장_저자' + chosenAuthors.length + '명_' + new Date().toISOString().slice(0, 10) + '.csv'); setNotice('선택한 ' + count(selectedPapers.length) + '건을 17개 항목의 CSV로 내보냈습니다.'); }
  const checkboxAll = <Checkbox aria-label="표시된 논문 전체 선택" checked={visiblePapers.length > 0 && selectedPapers.length === visiblePapers.length ? true : selectedPapers.length ? 'indeterminate' : false} onCheckedChange={v => setSelected(prev => { const next = new Set(prev); visiblePapers.forEach(p => v === true ? next.add(p.id) : next.delete(p.id)); return next; })} disabled={!visiblePapers.length}/>;
  return <div className="app-shell">
    <header className="topbar"><a href={isStandalone() ? "#" : "/"} className="brand"><span className="brand-mark"><Library size={23}/></span>논문대장<span className="brand-caption">{isStandalone() ? "LOCAL EDITION" : "RESEARCH RECORDS"}</span></a><div className="topbar-right"><span className="source-label">OpenAlex · {keyActive ? "탭 키 적용" : account?.hasSavedKey ? "계정 키 사용" : serverKeyConfigured ? "서버 키 사용" : "키 없는 조회"}</span><Button variant="ghost" onClick={() => { setSettings(true); }} disabled={loading || searching}><Settings2 size={17}/>검색 설정</Button><Button variant="ghost" size="icon" aria-label="항목 작성 안내" onClick={() => setHelp(true)}><CircleHelp size={20}/></Button></div></header>
    <div className="workspace"><aside className="search-panel">
      <div className="step-label">01 / AUTHOR SEARCH</div><h1>어떤 저자의<br/>논문을 찾으시나요?</h1>
      <form onSubmit={e => { e.preventDefault(); search(); }}><label htmlFor="author-query">저자 이름 / ORCID</label><div className="search-input"><Search size={18}/><Input id="author-query" value={query} onChange={e => setQuery(e.target.value)} placeholder="예: Geoffrey Hinton" maxLength={150}/></div><Button className="search-button" type="submit" disabled={searching}>{searching ? <Loader2 className="animate-spin" size={17}/> : <Search size={17}/>}저자 검색</Button></form>
      <div className="api-key-hint"><Info size={15}/><span>{keyActive ? "개인 API 키가 이 탭에 적용되어 있습니다." : account?.hasSavedKey ? "계정에 저장된 개인 API 키로 조회합니다." : serverKeyConfigured ? "서버에 설정된 키로 조회합니다. 개인 키도 적용할 수 있습니다." : "조회 제한이 발생하면 검색 설정에서 무료 개인 API 키를 적용하세요."}</span><button onClick={() => { setSettings(true); }} disabled={loading || searching}>설정</button></div><p className="field-hint">저자를 체크한 뒤 다른 이름을 검색해 추가하세요. 이전 선택은 유지됩니다. 영문 이름·ORCID·OpenAlex ID로 검색할 수 있습니다.</p>
      {searchError && <p className="error" role="alert">{searchError}</p>}
      <div className="author-heading"><h2>저자 후보</h2><span>{searched ? count(authorTotal) + '명' : '소속을 확인해 주세요'}</span></div>
      {searching && !authors.length ? <div className="skeleton-stack"><Skeleton className="h-28 w-full"/><Skeleton className="h-28 w-full"/></div> : authors.length ? <div className="author-list">{authors.map(a => <label htmlFor={'author-' + shortId(a.id)} className={'author-card ' + (chosenAuthors.some(v => v.id === a.id) ? 'active' : '')} key={a.id}><div className="author-card-title"><strong>{a.display_name}</strong><Checkbox id={'author-' + shortId(a.id)} checked={chosenAuthors.some(v => v.id === a.id)} onCheckedChange={() => pickAuthor(a)} disabled={loading} aria-label={a.display_name + ' 저자 선택'}/></div><p>{a.last_known_institutions?.map(i => i.display_name).join(' · ') || '소속 정보 없음'}</p><span>{count(a.works_count ?? 0)}개 연구문헌 · {shortId(a.id)}</span>{a.orcid && <small>ORCID {shortId(a.orcid)}</small>}</label>)}{authors.length < authorTotal && authorPage < 500 && <Button variant="outline" className="w-full" onClick={() => search(authorPage + 1)} disabled={searching}>저자 후보 더 보기</Button>}</div> : <Empty className="author-empty"><EmptyHeader><EmptyMedia variant="icon"><UserRound/></EmptyMedia><EmptyTitle>{searched ? '검색된 저자가 없습니다' : '저자를 검색해 시작하세요'}</EmptyTitle><EmptyDescription>{searched ? '다른 영문 표기나 ORCID로 검색해 보세요.' : '같은 이름의 연구자를 소속과 식별자로 구분합니다.'}</EmptyDescription></EmptyHeader></Empty>}
      <div className="sidebar-note"><Info size={16}/><span>선택한 저자의 문헌만 가져옵니다. 수록 여부와 저자 연결은 원문에서 한 번 더 확인하세요.</span></div>
    </aside><main className="main-panel">
      <div className="page-heading"><div><div className="step-label">02 / PUBLICATION RECORDS</div><h2>연구실적 정리</h2><p>여러 저자의 논문을 모아, 참여교수별 실적 양식으로 정리하세요.</p></div><Button className="export-button" disabled={!selectedPapers.length} onClick={download}><Download size={17}/>CSV 다운로드{selectedPapers.length > 0 && <span className="export-count">{count(selectedPapers.length)}</span>}</Button></div>
      <section className="query-bar" aria-label="논문 조회 조건"><div className="professor-field author-count-summary"><label>선택한 저자</label><strong><UserRound size={18}/>{chosenAuthors.length}명 <span>여러 명 선택 가능</span></strong></div><div><label htmlFor="year-from">시작 연도</label><Input id="year-from" type="number" min="1000" max="2100" placeholder="전체" value={from} onChange={e => setFrom(e.target.value)} disabled={loading}/></div><span className="year-divider">–</span><div><label htmlFor="year-to">종료 연도</label><Input id="year-to" type="number" min="1000" max="2100" placeholder="전체" value={to} onChange={e => setTo(e.target.value)} disabled={loading}/></div><Button disabled={!chosenAuthors.length || loading} onClick={() => loadPapers()}>{loading ? <Loader2 size={17} className="animate-spin"/> : <Search size={17}/>}선택 저자 논문 불러오기</Button></section>
      <div className="publication-options"><label><Checkbox checked={excludeArxiv} onCheckedChange={v => setExcludeArxiv(v === true)}/>arXiv 제외</label><label><Checkbox checked={mergeLatest} onCheckedChange={v => setMergeLatest(v === true)}/>같은 제목은 최신 1편만</label><div className="kind-filter"><label htmlFor="kind-filter">학술유형</label><Select value={publicationKind} onValueChange={v => setPublicationKind(v as PublicationKind | 'all')}><SelectTrigger id="kind-filter"><SelectValue/></SelectTrigger><SelectContent><SelectItem value="all">전체 유형</SelectItem>{Object.entries(kindLabels).map(([k, label]) => <SelectItem key={k} value={k}>{label}</SelectItem>)}</SelectContent></Select></div><AuthorFavorites payload={{ authors: chosenAuthors, professorNames: Object.fromEntries(chosenAuthors.map(a => [a.id, professorNames[a.id] || a.display_name])), from, to, excludeArxiv, mergeLatest, publicationKind }} onRestore={restoreFavorite} disabled={loading}/></div>
      <p className="filter-description">arXiv 제외는 주 출처가 arXiv인 문헌에 적용합니다. 다른 곳에 정식 게재된 문헌은 유지합니다. 동일 제목은 불러온 문헌에서 참여교수별로 최신 출판일 1편을 표시하며, 유형 필터를 먼저 적용합니다.</p>
      {chosenAuthors.length > 0 && <section className="chosen-authors" aria-label="선택한 저자와 참여교수 표기명">{chosenAuthors.map(a => <div key={a.id} className="chosen-author"><div className="chosen-author-info"><strong>{a.display_name}</strong><span>{shortId(a.id)} · {authorStats[a.id] ? count(authorStats[a.id].loaded) + ' / ' + count(authorStats[a.id].total) + '편 조회' : '조회 대기'}</span><div><a href={safeUrl(a.id)} target="_blank" rel="noopener noreferrer">저자 정보 ↗</a><a href={'https://scholar.google.com/scholar?q=' + encodeURIComponent('author:"' + a.display_name + '"')} target="_blank" rel="noopener noreferrer">Google Scholar ↗</a></div></div><div className="chosen-author-name"><label htmlFor={'name-' + shortId(a.id)}>참여교수 표기명</label><Input id={'name-' + shortId(a.id)} value={professorNames[a.id] ?? a.display_name} onChange={e => renameProfessor(a, e.target.value)} disabled={loading}/></div><Button variant="ghost" size="sm" onClick={() => pickAuthor(a)} disabled={loading} aria-label={a.display_name + ' 선택 해제'}>해제</Button></div>)}</section>}
      {paperError && <p className="error" role="alert">{paperError}</p>}{notice && <p className="notice" role="status"><Check size={16}/>{notice}</p>}
      <div className="stat-strip"><div><span>표시된 교수별 논문 행</span><strong>{count(visiblePapers.length)}<small> / 조회 {count(papers.length)}건</small></strong></div><div><span>직접 확인 완료</span><strong>{count(verifiedCount)}<small>건</small></strong></div><div><span>내보내기 항목</span><strong>17<small>개 열</small></strong></div><button onClick={() => setHelp(true)} className="guide-link"><Info size={17}/><span>자동 입력과<br/>직접 확인 항목 안내</span><ArrowUpRight size={16}/></button></div>
      <section className="records"><Tabs defaultValue="list"><div className="records-toolbar"><TabsList><TabsTrigger value="list">논문 목록</TabsTrigger><TabsTrigger value="form">17개 항목 표</TabsTrigger></TabsList><div className="record-actions"><Button variant="outline" size="sm" disabled={loading || classifying || !papers.some(p => p.doi && !p.arxiv)} onClick={() => classifyPapers(papers)}>Crossref 학술유형 보완</Button><span>{count(selectedPapers.length)}건 선택됨</span></div></div>
      {(classificationStatus || classifying) && <div className="classification-status" role="status">{classifying && <Loader2 size={14} className="animate-spin"/>}{classificationStatus || 'DOI 학술유형을 확인하고 있습니다.'}{classifying && <Button variant="ghost" size="sm" onClick={() => { ++classificationSeq.current; setClassifying(false); setClassificationStatus('학술유형 확인을 중단했습니다. 완료된 분류는 유지됩니다.'); }}>중단</Button>}</div>}
      <p className="table-hint">출처 정보가 없는 DOI 문헌은 Crossref로 자동 확인합니다. 분류가 맞지 않으면 ‘학술유형 보완’을 누르거나 논문 편집에서 직접 지정하세요. 데이터베이스에 수록되지 않은 문헌은 검색되지 않을 수 있습니다.</p>
      {!visiblePapers.length ? <Empty className="paper-empty"><EmptyHeader><EmptyMedia className="paper-empty-icon"><BookOpen size={34}/></EmptyMedia><EmptyTitle>{loading ? '학술정보를 불러오고 있습니다' : papers.length ? '현재 필터에 맞는 문헌이 없습니다' : loaded ? '해당 기간에 수록된 문헌이 없습니다' : chosenAuthors.length ? '조회할 기간을 정하고 논문을 불러오세요' : '논문 목록이 여기에 표시됩니다'}</EmptyTitle><EmptyDescription>{loading ? workingAuthor + '의 저자와 출판정보를 확인하는 중입니다.' : papers.length ? '학술유형이나 arXiv 제외 조건을 바꾸거나 다음 논문을 불러오세요.' : loaded ? '조회 기간을 넓히거나 다른 저자 프로필을 확인해 보세요.' : '제목, 저자, 출판정보를 가져온 뒤 17개 실적 항목을 편집할 수 있습니다.'}</EmptyDescription></EmptyHeader>{loading && <Loader2 className="animate-spin text-primary"/>}</Empty> : <>
      <TabsContent value="list"><Table><TableHeader><TableRow><TableHead className="check-cell">{checkboxAll}</TableHead><TableHead>논문명 / 저자</TableHead><TableHead>출판년월</TableHead><TableHead>학술지 · 학술대회</TableHead><TableHead>확인 상태</TableHead><TableHead><span className="sr-only">수정</span></TableHead></TableRow></TableHeader><TableBody>{visiblePapers.map(p => <TableRow key={p.id} data-state={selected.has(p.id) ? 'selected' : undefined}><TableCell className="check-cell"><Checkbox checked={selected.has(p.id)} onCheckedChange={v => toggle(p.id, v === true)} aria-label={p.values.title + ' 선택'}/></TableCell><TableCell className="paper-title-cell"><button className="paper-title" onClick={() => openEdit(p)}>{p.values.title || '제목 정보 없음'}</button><p className="participant-line">참여교수 · {p.values.professor}</p><p className="paper-byline">{p.values.firstAuthor || '제1저자 미확인'}{p.values.authorCount && Number(p.values.authorCount) > 1 && ' 외 ' + (Number(p.values.authorCount) - 1) + '명'}<span title={p.kindSource}>{kindLabels[p.publicationKind]}</span></p></TableCell><TableCell>{p.values.published || '—'}</TableCell><TableCell className="venue-cell">{p.values.venue || '정보 없음'}</TableCell><TableCell><span className={'status-tag ' + (p.verified ? 'verified' : '')}>{p.verified ? <Check size={12}/> : <Pencil size={12}/>} {p.verified ? '확인 완료' : '검토 필요'}</span></TableCell><TableCell><Button variant="ghost" size="icon" aria-label={p.values.title + ' 항목 수정'} onClick={() => openEdit(p)}><Pencil size={16}/></Button></TableCell></TableRow>)}</TableBody></Table></TabsContent>
      <TabsContent value="form"><p className="table-hint">열 순서는 제출 양식과 같습니다. 가로로 스크롤하고 논문별 ‘수정’을 눌러 입력하세요.</p><Table className="full-table"><TableHeader><TableRow><TableHead>{checkboxAll}</TableHead><TableHead>수정</TableHead>{fields.map(f => <TableHead key={f.key} className={f.manual ? 'manual-head' : ''}>{f.label}{f.manual && <span>직접 확인</span>}</TableHead>)}</TableRow></TableHeader><TableBody>{visiblePapers.map(p => <TableRow key={p.id}><TableCell><Checkbox checked={selected.has(p.id)} onCheckedChange={v => toggle(p.id, v === true)} aria-label={p.values.title + ' 선택'}/></TableCell><TableCell><Button variant="ghost" size="sm" onClick={() => openEdit(p)}>수정</Button></TableCell>{fields.map(f => <TableCell key={f.key}><span className={p.values[f.key] ? '' : 'blank-value'}>{p.values[f.key] || '—'}</span></TableCell>)}</TableRow>)}</TableBody></Table></TabsContent></>}
      </Tabs>{papers.length > 0 && <div className="table-footer"><span>표시 {count(visiblePapers.length)}건 · 조회 {count(papers.length)} / {count(total)}건 · 교수별 각 100편씩 조회{loading && ' · ' + workingAuthor + ' 조회 중'}</span>{moreAvailable && <Button variant="outline" size="sm" onClick={() => loadPapers(true)} disabled={loading}>{loading ? <Loader2 size={15} className="animate-spin"/> : <Plus size={15}/>}다음 / 미조회 논문 불러오기</Button>}</div>}</section>
      <div className="bottom-note"><Info size={16}/><p>SCIE·BK 인정 구분, IF, 연구보조원 수, 주저자 여부, 기여율, 사사 기관 수는 직접 확인해 입력하세요. 조회 결과에는 논문 외 문헌도 포함될 수 있습니다. 공동 논문은 참여교수별로 한 행씩 표시되며, 총 건수도 교수별 행 기준입니다. <strong>조회 결과는 최대 1시간 캐싱됩니다. 논문 편집 내용은 이 탭에서만 유지됩니다. 저자 선택과 조회 조건은 즐겨찾기로 저장할 수 있습니다. 작업 후 CSV를 저장하세요.</strong></p></div>
    </main></div>
    <Dialog open={!!editing} onOpenChange={v => { if (!v) closeEdit(); }}><DialogContent className="edit-dialog"><DialogHeader><div className="step-label">PUBLICATION DETAILS</div><DialogTitle>논문 실적 항목 편집</DialogTitle><DialogDescription>자동 입력된 값도 수정할 수 있습니다. 빈칸은 CSV에서도 빈칸으로 유지됩니다.</DialogDescription></DialogHeader>{editing && <>
      <div className="edit-source"><span>OpenAlex 저자 역할: <strong>{editing.role}</strong></span><a href={safeUrl(editing.source)} target="_blank" rel="noopener noreferrer">원자료 확인 <ArrowUpRight size={14}/></a>{safeUrl(editing.values.link) && <a href={safeUrl(editing.values.link)} target="_blank" rel="noopener noreferrer">논문 링크 <ArrowUpRight size={14}/></a>}</div>
      <div className="publication-kind-editor"><label htmlFor="edit-kind">학술유형</label><Select value={editing.publicationKind} onValueChange={v => setEditing(p => p ? { ...p, publicationKind: v as PublicationKind, kindSource: '직접 확인' } : p)}><SelectTrigger id="edit-kind"><SelectValue/></SelectTrigger><SelectContent>{Object.entries(kindLabels).map(([k, label]) => <SelectItem key={k} value={k}>{label}</SelectItem>)}</SelectContent></Select><small>분류 근거: {editing.kindSource} · 17개 CSV 열에는 추가하지 않습니다.</small></div>
      {editing.warnings.map(w => <p key={w} className="error">{w}</p>)}<div className="edit-form">{fields.map((f, i) => <div key={f.key} className={'edit-field ' + (['title', 'coauthors', 'link', 'venue'].includes(f.key) ? 'wide' : '')}><label htmlFor={'edit-' + f.key}><span className="field-number">{String(i + 1).padStart(2, '0')}</span>{f.label}{f.manual && <small>직접 확인</small>}</label>{f.key === 'isLead' ? <Select value={editing.values.isLead || 'unset'} onValueChange={v => setValue('isLead', v === 'unset' ? '' : v)}><SelectTrigger id="edit-isLead" className="w-full"><SelectValue/></SelectTrigger><SelectContent><SelectItem value="unset">미입력</SelectItem><SelectItem value="Y">Y · 주저자</SelectItem><SelectItem value="N">N · 해당 없음</SelectItem></SelectContent></Select> : ['title', 'coauthors'].includes(f.key) ? <textarea id={'edit-' + f.key} value={editing.values[f.key]} onChange={e => setValue(f.key, e.target.value)} rows={2}/> : <Input id={'edit-' + f.key} value={editing.values[f.key]} onChange={e => setValue(f.key, e.target.value)} placeholder={f.key === 'published' ? 'YYYY-MM (월 미상: YYYY)' : f.key === 'contribution' ? '예: 25%' : f.key === 'category' ? '예: SCIE / BK인정 / h5-index 50 이상' : f.manual ? '확인 후 입력' : '자료 없음'}/>}{f.key === 'isLead' && <p className="field-hint">제1·교신·공동주저자 인정은 기관 기준과 원문으로 판단하세요.</p>}{f.key === 'impactFactor' && <p className="field-hint">제출 기준연도의 JCR IF 또는 기관 인정 IF를 입력하세요.</p>}</div>)}</div>
      <div className="edit-bottom"><Button variant="outline" onClick={enrich} disabled={!editing.doi || enriching}>{enriching ? <Loader2 size={16} className="animate-spin"/> : <Plus size={16}/>}Crossref로 빈 서지정보 보완</Button><label className="verify-label"><Checkbox checked={editing.verified} onCheckedChange={v => setEditing(p => p ? { ...p, verified: v === true } : p)}/>원문·기관 기준 확인 완료</label></div>{editError && <p className="field-hint" role="status">{editError}</p>}<DialogFooter><Button variant="outline" onClick={closeEdit}>취소</Button><Button onClick={commitEdit} disabled={enriching}><Check size={16}/>변경사항 반영</Button></DialogFooter></>}</DialogContent></Dialog>
    {isStandalone() ? <GoogleSettings open={settings} onOpenChange={setSettings} onApply={applyKey} keyActive={keyActive} disabled={loading || searching}/> : <SearchSettings open={settings} onOpenChange={setSettings} account={account} onAccountChange={setAccount} accountError={accountError} tabKeyActive={keyActive} serverKeyConfigured={serverKeyConfigured} onApply={applyKey} disabled={loading || searching}/>}
    <Dialog open={help} onOpenChange={setHelp}><DialogContent className="help-dialog"><DialogHeader><DialogTitle>17개 실적 항목 작성 안내</DialogTitle><DialogDescription>자동 수집 정보와 기관 확인 정보를 함께 관리합니다.</DialogDescription></DialogHeader><div className="help-copy"><h3>서지정보 · 11개 항목</h3><p>참여교수, 제1저자, 공동저자, 논문명, 페이지, 볼륨, 출판년월, 저자수, 학술지·학술대회명, DOI·링크, ISSN을 가능한 범위에서 채웁니다. 참여교수 표기명을 바꾸면 해당 저자의 불러온 논문에도 적용됩니다. 여러 저자를 선택할 수 있고, 공동 논문은 교수별로 별도 행을 만들어 기여율과 주저자 여부를 각각 입력합니다.</p><h3>직접 확인 · 6개 항목</h3><p>구분, 연구보조원수, 참여교수 주저자여부, IF, 기여율, 사사 기관 수는 직접 입력합니다. h5-index는 저자 h-index와 다르며, SCIE·BK·CS 우수학술대회 인정 여부와 IF는 해당 기관의 기준연도 자료로 확인하세요.</p><h3>누락 정보와 출판일</h3><p>서지정보는 누락되거나 잘못 연결될 수 있습니다. DOI가 있으면 Crossref로 빈 서지정보를 보완할 수 있습니다. 온라인 공개일과 인쇄 출판일이 다를 수 있고, 월이 불명확한 자료도 있으므로 제출 기준에 맞춰 수정하세요. 사사 기관 수는 원문 사사문을 기준으로 확인합니다.</p><h3>저장과 CSV</h3><p>선택한 교수별 논문 행만 17개 열 순서로 저장합니다. 저자를 검색해 추가하거나 해제해도 다른 저자의 선택은 유지됩니다. CSV는 한글 표시를 위한 UTF-8 BOM을 포함합니다. ISSN의 앞자리 0을 보존하려면 Excel의 ‘텍스트/CSV에서 가져오기’로 열고 해당 열 형식을 텍스트로 지정하세요. CSV에는 현재 필터에서 표시되고 선택된 행만 들어갑니다. 최신 1편 옵션은 대소문자·공백을 정리한 동일 제목을 참여교수별로 비교합니다. 같은 날이면 OpenAlex ID로 일정하게 선택합니다. 비슷하지만 다른 제목은 자동으로 합치지 않습니다. 즐겨찾기는 저자 목록과 조회 조건을 저장하며, 논문 편집 내용은 탭을 닫으면 사라집니다.</p><a href="https://help.openalex.org/api/" target="_blank" rel="noopener noreferrer">OpenAlex 데이터 안내 ↗</a></div></DialogContent></Dialog>
  </div>;
}
