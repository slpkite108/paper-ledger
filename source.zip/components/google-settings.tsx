'use client';
import { useEffect, useState, useSyncExternalStore } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { connectGoogle, deleteGoogleKey, disconnectGoogle, googleClientId, googleUser, prepareGoogle, readGoogleKey, saveGoogleKey, setGoogleClientId, subscribeGoogle } from '@/lib/google-store';

export function GoogleSettings({ open, onOpenChange, onApply, keyActive, disabled }: { open: boolean; onOpenChange: (v: boolean) => void; onApply: (key: string) => void; keyActive: boolean; disabled: boolean }) {
  const user = useSyncExternalStore(subscribeGoogle, googleUser, () => null);
  const [draft, setDraft] = useState(''); const [clientId, setClientId] = useState(''); const [ready, setReady] = useState(false); const [configured, setConfigured] = useState(false);
  const [error, setError] = useState(''); const [message, setMessage] = useState(''); const [busy, setBusy] = useState(false);
  async function prepare() { if (!googleClientId()) return; setConfigured(true); try { await prepareGoogle(); setReady(true); } catch (e) { setError((e as Error).message); } }
  useEffect(() => { setClientId(googleClientId()); void prepare(); }, []);
  const fileMode = typeof window !== 'undefined' && window.location.protocol === 'file:';
  function close(v: boolean) { if (busy) return; if (!v) { setDraft(''); setError(''); setMessage(''); } onOpenChange(v); }
  function valid() { if (!/^[\x21-\x7e]{8,512}$/.test(draft.trim())) { setError('OpenAlex에서 발급한 개인 API 키를 입력하세요.'); return false; } return true; }
  async function login() {
    setBusy(true); setError(''); setMessage(''); onApply('');
    try { await connectGoogle(); const key = await readGoogleKey(); onApply(key); setMessage(key ? 'Google 계정에 연결하고 저장된 개인 키를 적용했습니다.' : 'Google 계정에 연결했습니다. 즐겨찾기와 키를 계정에 저장할 수 있습니다.'); }
    catch (e) { setError((e as Error).message); } finally { setBusy(false); }
  }
  async function store(remove = false) {
    if (!remove && !valid()) return;
    setBusy(true); setError(''); setMessage('');
    try { if (remove) { await deleteGoogleKey(); onApply(''); } else { await saveGoogleKey(draft.trim()); onApply(draft.trim()); setDraft(''); } setMessage(remove ? 'Google 저장소의 개인 키를 삭제했습니다.' : 'Google 저장소에 키를 저장하고 이 탭에 적용했습니다.'); }
    catch (e) { setError((e as Error).message); } finally { setBusy(false); }
  }
  return <Dialog open={open} onOpenChange={close}><DialogContent className="settings-dialog"><DialogHeader><DialogTitle>Google 계정과 검색 설정</DialogTitle><DialogDescription>Google 계정으로 즐겨찾기와 개인 API 키를 동기화합니다.</DialogDescription></DialogHeader>
    <div className="account-box"><strong>{user?.name || 'Google 계정'}</strong><p>{user?.email || (configured ? 'Google 계정을 연결하면 여러 기기에서 불러올 수 있습니다.' : 'Google 로그인 설정 전입니다. 아래 앱 설정 안내를 확인하세요.')}</p><div className="record-actions"><Button variant="outline" disabled={!configured || !ready || fileMode || busy || disabled} onClick={login}>{user ? 'Google 계정 다시 연결' : 'Google 계정으로 연결'}</Button>{user && <Button variant="ghost" disabled={busy} onClick={() => { disconnectGoogle(); onApply(''); setMessage('Google 연결과 이 탭의 키를 해제했습니다.'); }}>연결 종료</Button>}</div><small>{fileMode ? 'Google 연결은 GitHub Pages의 HTTPS 주소에서 사용할 수 있습니다.' : user ? '즐겨찾기 저장 위치: 이 Google 계정의 앱 전용 저장소' : '현재 즐겨찾기 저장 위치: 이 브라우저'}</small></div>
    <p className="field-hint">Google Drive의 앱 전용 비공개 영역을 사용합니다. 이름·이메일과 이 앱의 저장 데이터만 사용하며, 일반 Drive 문서 접근 권한은 요청하지 않습니다. 새로고침 또는 연결 만료 후에는 다시 연결해 저장된 키를 불러오세요.</p>
    <label htmlFor="openalex-key">OpenAlex API 키</label><Input id="openalex-key" type="password" autoComplete="off" spellCheck={false} value={draft} onChange={e => setDraft(e.target.value)} maxLength={512} placeholder={user?.hasSavedKey ? '저장된 키 있음 · 변경할 키 입력' : '발급받은 개인 키 붙여넣기'} disabled={busy}/>
    <a className="field-hint" href="https://openalex.org/settings/api" target="_blank" rel="noopener noreferrer">OpenAlex에서 무료 키 발급 ↗</a><p className="field-hint">현재: {keyActive ? '개인 키 적용됨' : '키 없이 조회'}. ‘Google에 저장’을 누른 경우에만 개인 키를 Google Drive에 저장합니다. ‘이 탭에 적용’은 메모리에만 보관합니다. 원문 키를 HTML·GitHub·CSV·브라우저 저장소에 기록하지 않습니다.</p>
    {error && <p className="error" role="alert">{error}</p>}{message && <p className="field-hint" role="status">{message}</p>}
    <DialogFooter className="key-actions">{keyActive && <Button variant="outline" disabled={busy || disabled} onClick={() => onApply('')}>탭 키 해제</Button>}{user?.hasSavedKey && <Button variant="outline" disabled={busy || disabled} onClick={() => store(true)}>Google 키 삭제</Button>}<Button variant="outline" disabled={busy || disabled} onClick={() => { if (valid()) { onApply(draft.trim()); close(false); } }}>이 탭에 적용</Button><Button disabled={!user || busy || disabled} onClick={() => store()}>Google에 저장</Button></DialogFooter>
    <details className="google-setup"><summary>앱 설정 · Google 클라이언트 ID 발급 안내</summary><ol><li><a href="https://console.cloud.google.com/auth/clients" target="_blank" rel="noopener noreferrer">Google Cloud ↗</a>에서 프로젝트를 만들고 Google Auth Platform에 앱 이름과 지원 이메일을 설정합니다.</li><li>웹 애플리케이션 OAuth 클라이언트를 만들고 승인된 JavaScript 원본에 <code>{typeof window !== 'undefined' && !fileMode ? window.location.origin : 'https://slpkite108.github.io'}</code>를 등록합니다. 경로 /paper-ledger는 원본에 넣지 않습니다.</li><li>같은 프로젝트에서 Google Drive API를 활성화합니다. 기본 프로필·이메일·openid와 <code>https://www.googleapis.com/auth/drive.appdata</code>권한을 설정하고 테스트 사용자에 본인 계정을 추가합니다.</li><li>발급한 클라이언트 ID를 아래에 입력합니다. 모든 사용자에게 적용하려면 저장소의 config.js에 공개 클라이언트 ID만 넣습니다. 클라이언트 비밀값은 필요하지 않습니다.</li></ol><label htmlFor="google-client-id">공개 OAuth 클라이언트 ID</label><Input id="google-client-id" value={clientId} onChange={e => setClientId(e.target.value)} placeholder="…apps.googleusercontent.com" maxLength={300} disabled={busy}/><Button variant="outline" disabled={busy || !clientId.trim()} onClick={() => { try { setGoogleClientId(clientId); onApply(''); setError(''); void prepare(); setMessage('클라이언트 ID를 이 브라우저에 적용했습니다. Google 계정 연결을 눌러주세요.'); } catch (e) { setError((e as Error).message); } }}>이 브라우저에 ID 적용</Button><p>Google 검증이나 공개 전환이 요구될 수 있습니다. 키는 Google 계정의 접근 제어로 보호되며, 앱 자체의 별도 비밀번호 암호화는 적용하지 않습니다.</p><a href="https://developers.google.com/identity/oauth2/web/guides/use-token-model?hl=ko" target="_blank" rel="noopener noreferrer">Google 공식 연결 안내 ↗</a></details>
  </DialogContent></Dialog>;
}
