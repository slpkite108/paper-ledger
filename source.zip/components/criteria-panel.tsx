'use client';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Choice } from './layout-settings';
import { parseTsv, type Layout } from '@/lib/layouts';
import { applyReference, builtinBk, criteriaOptions, matchReference, referenceSchema, type Reference } from '@/lib/criteria';
import type { Paper } from '@/lib/papers';

export function CriteriaPanel({layout,onLayout,papers,onApply}:{layout:Layout;onLayout:(v:Layout)=>void;papers:Paper[];onApply:(values:Paper[])=>void}) {
  const [open,setOpen]=useState(false);const [error,setError]=useState('');const [message,setMessage]=useState('');const [checked,setChecked]=useState<Set<string>>(new Set());const [overrides,setOverrides]=useState<Record<string,string>>({});const [page,setPage]=useState(0);const [find,setFind]=useState('');
  const [name,setName]=useState('');const [year,setYear]=useState(String(new Date().getFullYear()));const [url,setUrl]=useState('');const [paste,setPaste]=useState('');
  const references=[builtinBk,...layout.criteria.custom];const reference=references.find(r=>r.id===layout.criteria.selected);
  const options=[...criteriaOptions,...layout.criteria.custom.map(r=>({key:r.id,label:r.name+' ('+r.year+')'}))];
  const candidates=reference?papers.map(p=>{const matches=matchReference(p,reference);const row=overrides[p.id]!==undefined?reference.rows[Number(overrides[p.id])]:matches.length===1?matches[0]:undefined;return{paper:p,row,ambiguous:matches.length>1};}):[];
  const rowOptions=reference?[{key:'none',label:'미확인 / 기준표에서 직접 선택'},...reference.rows.map((r,i)=>({key:String(i),label:(r.alias?r.alias+' · ':'')+r.venue})).filter(r=>!find||r.label.toLowerCase().includes(find.toLowerCase()))]:[];
  function reset() {setChecked(new Set());setOverrides({});setPage(0);setError('');setMessage('');setFind('');}
  function addReference() {try {
    if(layout.criteria.custom.length>=10)throw new Error('추가 기준표는 10개까지입니다. 프리셋을 나누어 저장하세요.');
    const data=parseTsv(paste);if(data.length<2)throw new Error('머리글과 데이터 행을 함께 붙여넣으세요.');
    const names=data[0].map(x=>x.trim().toLowerCase().replace(/[\s-]/g,''));
    const pick=(row:string[],aliases:string[])=>{const i=names.findIndex(n=>aliases.includes(n));return i<0?'':(row[i]||'').trim();};
    const rows=data.slice(1).map(row=>({venue:pick(row,['학술지명','학술대회명','학회명','이름','venue']),issn:pick(row,['issn']),alias:pick(row,['약칭','alias']),category:pick(row,['구분','category']),value:pick(row,['값','h5index','h5','value']),impactFactor:pick(row,['인정if','if','impactfactor'])}));
    const parsed=referenceSchema.safeParse({id:crypto.randomUUID(),name,year,url,rows});if(!parsed.success)throw new Error('기준표 이름·연도·http(s) 출처와 각 행을 확인하세요. 구분은 SCIE, BK인정, h5-index, 참고 중 하나이며, h5 값은 정수입니다.');
    onLayout({...layout,criteria:{selected:parsed.data.id,custom:[...layout.criteria.custom,parsed.data]}});reset();setMessage(parsed.data.rows.length+'개 항목의 기준표를 추가했습니다. 양식·프리셋 저장으로 보관하세요.');
  } catch(e){setError((e as Error).message);} }
  function apply() {if(!reference)return;const changes=candidates.filter(c=>c.row&&checked.has(c.paper.id)&&c.row.category!=='참고').map(c=>applyReference(c.paper,reference,c.row!));onApply(changes);setMessage(changes.length+'건에 구분·근거를 반영했습니다. 기존 IF는 유지하고 빈 IF만 보완했습니다.');setChecked(new Set());}
  const sourceInfo:Record<string,{url:string;description:string}>={
    'kiise-2024':{url:'https://aisociety.kr/sub/sub_04_02.php',description:'공식 안내에 게시된 최신 개편 목록은 2024판(216개)입니다. 2026-05-22 학회 공지는 연구재단 인정 논의 중임을 설명합니다. BK 목록과 별개입니다. 원문을 확인하거나 다른 기준표로 가져오세요.'},
    'scie-live':{url:'https://mjl.clarivate.com/',description:'ISSN으로 학술지를 찾고 Science Citation Index Expanded 수록 여부와 수록기간을 확인하세요. 현재 수록 상태와 논문 출판 당시 수록 여부는 다를 수 있습니다. IF만으로 SCIE 여부를 판정하지 않습니다.'},
    'h5-cs-2025':{url:'https://scholar.google.com/citations?view_op=top_venues&hl=ko&vq=eng',description:'Google 공식 안내 기준 2025년 7월판입니다(2020–2024 발행 논문). Engineering & Computer Science에서 세부 CS 분야를 선택하세요. 학술지·학술대회 지표이며 저자 h-index와 다릅니다.'},
    'h5-all-2025':{url:'https://scholar.google.com/citations?view_op=top_venues&hl=ko',description:'Google 공식 안내 기준 2025년 7월판입니다. 언어·분야를 변경하거나 학술지명으로 검색하세요. 미수록은 h5-index 50 미만을 뜻하지 않습니다.'},
  }; const external=sourceInfo[layout.criteria.selected];
  return <><Button variant="outline" onClick={()=>{reset();setOpen(true);}}>인정 기준·자료 선택</Button><Dialog open={open} onOpenChange={setOpen}><DialogContent className="layout-dialog"><DialogHeader><DialogTitle>인정 기준 확인 · CS 우선</DialogTitle><DialogDescription>기준 자료를 선택하고, 일치 후보를 검토한 뒤 반영하세요. 최신 공개 자료 조사일: 2026-09-16. 자료의 개정판과 공고 연도는 다를 수 있습니다.</DialogDescription></DialogHeader>
    <Choice label="적용할 인정 기준 자료" value={layout.criteria.selected} options={options} onChange={selected=>{onLayout({...layout,criteria:{...layout.criteria,selected}});reset();}}/>
    {external&&<div className="reference-info"><p>{external.description}</p><a href={external.url} target="_blank" rel="noopener noreferrer">선택한 공식 자료 열기 ↗</a><p>실시간 자동 수집은 연결되어 있지 않습니다. 논문 편집의 ‘SCIE · BK · h5-index’에서 확인 결과·기준연도·출처를 기록하거나 아래에 확인한 기준표를 가져오면 일괄 대조할 수 있습니다.</p></div>}
    {reference&&<><div className="reference-info"><strong>{reference.name} · {reference.rows.length}개</strong><p>{reference.id===builtinBk.id?'2026-03-23 대한민국과학상·공학상 공고에 첨부된 BK 목록을 수록했습니다. 공고 연도 2026은 목록이 2026년에 개정되었다는 뜻이 아닙니다.':'사용자가 가져온 기준표입니다. 최신판 및 인정 범위를 출처에서 확인하세요.'}</p><a href={reference.url} target="_blank" rel="noopener noreferrer">기준표 출처 ↗</a><p>ISSN 또는 연도·회차·문장부호를 정리한 학술지명/약칭이 같을 때만 후보로 표시합니다. 일치하지 않으면 미확인입니다. 학술대회 발표 트랙·워크숍과 기관 적용 여부를 검토한 행만 체크하세요.</p></div>
    <div className="preset-actions"><strong>표시·선택된 논문 {papers.length}건 중 후보 {candidates.filter(c=>c.row).length}건</strong><Input aria-label="수동 선택용 기준표 검색" placeholder="직접 선택 목록 검색: CVPR, Nature…" value={find} onChange={e=>setFind(e.target.value)}/></div>
    <div className="criteria-table"><Table><TableHeader><TableRow><TableHead>검토</TableHead><TableHead>논문 / 검색된 출처</TableHead><TableHead>기준표 항목 (직접 변경 가능)</TableHead><TableHead>기록할 값</TableHead></TableRow></TableHeader><TableBody>{candidates.slice(page*50,page*50+50).map(c=><TableRow key={c.paper.id}><TableCell><Checkbox disabled={!c.row||c.row.category==='참고'} checked={checked.has(c.paper.id)} aria-label={c.paper.values.title+' 기준 검토 완료'} onCheckedChange={v=>setChecked(prev=>{const next=new Set(prev);v===true?next.add(c.paper.id):next.delete(c.paper.id);return next;})}/></TableCell><TableCell><strong>{c.paper.values.title}</strong><p>{c.paper.values.venue||'학술지·학술대회명 없음'} · {c.paper.values.issn}</p>{c.ambiguous&&<small>여러 후보가 있어 직접 선택해야 합니다.</small>}</TableCell><TableCell><Choice label={c.paper.values.title+' 기준표 매칭'} value={c.row?String(reference.rows.indexOf(c.row!)):'none'} options={c.row&&!rowOptions.some(o=>o.key===String(reference.rows.indexOf(c.row!)))?[...rowOptions,{key:String(reference.rows.indexOf(c.row!)),label:c.row.venue}]:rowOptions} onChange={v=>{setOverrides({...overrides,[c.paper.id]:v==='none'?'-1':v});setChecked(prev=>{const next=new Set(prev);next.delete(c.paper.id);return next;});}}/></TableCell><TableCell>{c.row?c.row.category+(c.row.category==='h5-index'?' '+c.row.value:'')+(c.row.impactFactor?' · 인정 IF '+c.row.impactFactor:''):'미확인'}</TableCell></TableRow>)}</TableBody></Table></div>
    {!papers.length&&<p className="field-hint">논문을 조회하고 행을 선택하면 기준표와 대조합니다.</p>}<div className="preset-actions"><Button variant="outline" disabled={!page} onClick={()=>setPage(page-1)}>이전 50건</Button><span>{page+1} / {Math.max(1,Math.ceil(candidates.length/50))}</span><Button variant="outline" disabled={(page+1)*50>=candidates.length} onClick={()=>setPage(page+1)}>다음 50건</Button><Button disabled={!checked.size} onClick={apply}>검토한 {checked.size}건 반영</Button></div></>}
    <details className="header-import"><summary>다른 분야·기관의 기준표 추가 (Excel 붙여넣기)</summary><p>머리글: 학술지명, ISSN, 약칭, 구분, 값, 인정 IF. ‘학술지명’과 ‘구분’은 필수이며 나머지는 비워도 됩니다. 구분은 SCIE / BK인정 / h5-index / 참고 중 하나입니다. h5-index는 ‘값’에 숫자를 넣으세요. 최대 5,000행입니다.</p><div className="reference-form"><Input aria-label="기준표 이름" placeholder="기준표 이름 / 분야" value={name} onChange={e=>setName(e.target.value)} maxLength={100}/><Input aria-label="기준표 연도" placeholder="자료 기준연도" value={year} onChange={e=>setYear(e.target.value)} maxLength={4}/><Input aria-label="기준표 출처" placeholder="공식 출처 URL" value={url} onChange={e=>setUrl(e.target.value)}/></div><textarea rows={4} aria-label="Excel 인정 기준표" value={paste} onChange={e=>setPaste(e.target.value)} placeholder={'학술지명\tISSN\t약칭\t구분\t값\t인정 IF'}/><Button onClick={addReference}>기준표 추가·선택</Button></details>
    {error&&<p role="alert" className="error">{error}</p>}{message&&<p role="status" className="notice">{message}</p>}<p className="field-hint">선택한 자료와 추가 기준표는 양식·프리셋에 함께 저장할 수 있습니다. 목록에 없거나 자료가 없는 논문을 자동으로 비인정 처리하지 않습니다.</p>
  </DialogContent></Dialog></>;
}
